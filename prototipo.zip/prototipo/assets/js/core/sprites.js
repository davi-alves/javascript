/**
 * Created by PyCharm.
 * User: Silvio Lucena Junior
 * Date: 28/08/12
 * Time: 13:43
 * To change this template use File | Settings | File Templates.
 */

Crafty.sprite("assets/img/spritesheets/ship-medium.png", {
    SprNave: [0, 0, 43, 59]
});

Crafty.sprite("assets/img/spritesheets/bullet.png", {
    SprBala: [0, 0, 30, 30]
});

Crafty.sprite("assets/img/spritesheets/ships.png", {
    SprInimigo: [0, 0, 44, 47]
});